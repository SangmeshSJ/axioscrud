import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import {  Items } from '../Model/item';


 

@Injectable({

  providedIn: 'root'

})

export class ItemService {
    

  constructor(private http:HttpClient) { }

  getItems(){
    return this.http.get<Items[]>('http://localhost:500/api/items');
  }

  addItem(item:Items){
    return this.http.post('http://localhost:500/api/item',item);
  }

  
  deleteItem(_id:number){
    return this.http.delete('http://localhost:500/api/item' + "/" +_id)
  }

  editItem(_id:number){
    return  this.http.put<Items>('http://localhost:500/api/item' +"/" +_id,Items);
  }
}

