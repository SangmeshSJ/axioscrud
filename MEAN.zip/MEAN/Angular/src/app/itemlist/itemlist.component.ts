import { Component, OnInit } from '@angular/core';
import { Items } from '../Model/item';
import { ItemService } from '../Services/item.service';

@Component({
  selector: 'app-itemlist',
  templateUrl: './itemlist.component.html',
  styleUrls: ['./itemlist.component.css']
})
export class ItemlistComponent implements OnInit {
  itemList:Items[]=[];

  constructor(private itemservice :ItemService) { }

  ngOnInit() {
  this.getitems();
  }

  getitems(){
    this.itemservice.getItems().subscribe(items=>
      {
        this.itemList=<Items[]>items
      })
  }
  


}
