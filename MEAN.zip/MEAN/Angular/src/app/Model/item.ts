export class Items{
    _id?:number
    itemname:string
    itemquantity:string
    itembought:boolean
}