import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ItemService } from './Services/item.service';
import { Items } from './Model/item';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'Angularfrontend';
  
  addForm: FormGroup;
  submitted:boolean=false;
  item:Items[]=[]
  constructor(private formbuilder:FormBuilder,
    private itemservice: ItemService, private router: Router) { 
      
    }

  ngOnInit() {
    this.addForm = this.formbuilder.group({
      _id: [],
      itemname: ['',Validators.required],
      itemquantity: ['',Validators.required],
      itembought:['',Validators.required]
    });
    this.itemservice.getItems().subscribe(data=>{
      this.item=data});
  }
 
 
  onSubmit1(){
    //write the code to fetch the data
    //from service
    this.submitted=true;
    if(this.addForm.invalid){
      return;
    }
    this.itemservice.addItem(this.addForm.value).subscribe();
    this.itemservice.getItems().subscribe(data=>{
      this.item=data;
    });
    this.itemservice.getItems().subscribe();
    // data=>
    //   {this.addForm.controls.value}
    
  }

  deleteItems(item){
    this.itemservice.deleteItem(item._id).subscribe(data => {
      this.item = this.item.filter(u => u !== item);        
    })
  }
   
}
