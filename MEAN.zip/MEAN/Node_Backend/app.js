var express = require('express');//y importing express model by using require

var mongoose = require('mongoose');

const route =  require('./routers/router');//importing from router.js
const cors = require('cors')
mongoose.connect('mongodb://localhost:27017/mydb');//connecting to mongodb
mongoose.connection.on('connected',()=>
{
    console.log('Mongodb Connection is Open' )
})

var app = new express();
app.get('/',(req,res)=>
{
    res.send('Hello from Root Path')
});

//add a middleware to parse the data in json
app.use(express.json());//solves itemname not found in postman
app.use(cors());
// add an middleware to configure the router
app.use('/api',route); //solves cannotGET in browser



const port = 500;
app.listen(port,function()
{
    console.log('Server started on port number '+ port)
});

