var express = require('express');

var router = express.Router();

const items = require('../model/items')
//these are the few methods in Router Class
// router.get();
// router.post();

router.get('/', (req,res)=>
{
    console.log('I am from different route module with console');
    res.send('I am from different model ');
});

//coming from items.js
router.post('/item',(req,res,next)=>{
    const newitem = new items(
        {
            itemname: req.body.itemname,
            itemquantity: req.body.itemquantity,
            itembought: req.body.itembought
        });//item close

newitem.save((err, data)=>
{
    if(err){
    res.json(err)
    }
    else{
        res.json(data)
    }
});
});//post close


router.get('/items', (req, res) => 
{
    items.find({}, (err, item) =>
     {
      if (err) {
        res.json(err);
      } 
      else {
        res.json(item);
     }
})
})

router.delete('/item/:id',(req,res) =>
{
    items.findByIdAndRemove({_id: req.params.id},function(err,result){
        if(err){
            res.json(err);
        }
        else{
            res.json(result);
        }
    });
});

router.put('/item/:id', (req, res, next)=> {
    items.findOneAndUpdate({_id: req.params.id},
     {
       $set: {
        itemname: req.body.itemname,
        itemquantity: req.body.itemquantity,
        itembought: req.body.itembought
       }
     }, function(err,result){
       if(err){
         res.json(err);
       }
       else{
         res.json({msg: 'item has been updated successfully'},result)
       }
     });
    });
module.exports=router;