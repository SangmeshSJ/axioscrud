const mongoose = require('mongoose');
const itemschema = mongoose.Schema(  //database
    {
        itemname:{
            type:String,
            required:false
        },
        itemquantity:{
            type:String,
            required:false
        },
        itembought:{
            type:Boolean,
            required:false
        }
    });
    module.exports = mongoose.model('items',itemschema)